import pandas as pd
import os

def acsf_to_csv(acsf_file, output_csv):
    # Get the folder name (last directory in the path)
    folder_name = os.path.basename(os.path.dirname(os.path.abspath(acsf_file)))

    # Read the ACSF file
    with open(acsf_file, 'r') as file:
        lines = file.readlines()

    # Initialize lists to store headers and values
    headers = ["Folder_Name"]  # First column will be the folder name
    values = [folder_name]  # Add the folder name as the first value

    # Initialize atom_number as None
    atom_number = None

    # Process lines
    for line in lines:
        line = line.strip()  # Remove extra whitespace
        if line.startswith("Atom"):  # Identify atom sections
            # Example line: "Atom 1:"
            atom_number = line.split()[1][:-1]  # Extract atom number (e.g., "1" from "Atom 1:")
        elif line and not line.startswith("-") and not line.startswith("="):  # Read the values
            # Ensure atom_number has been initialized before processing values
            if atom_number is not None:
                g_values = line.split()  # Split the line into individual G values
                for i, g_value in enumerate(g_values):
                    headers.append(f"{atom_number}_G{i+1}")  # Create headers like "1_G1", "1_G2", ...
                    values.append(float(g_value))  # Append the corresponding value
            else:
                # Skip unexpected lines before "Atom X:" appears
                #print(f"Skipping line due to missing atom number: {line}")
                continue  # Skip without further processing

    # Ensure we have data to save
    if not headers or not values:
        raise ValueError("No valid data found in the file.")

    # Create a DataFrame
    df = pd.DataFrame([values], columns=headers)

    # Save to CSV
    try:
        df.to_csv(output_csv, index=False)
        print(f"Converted file saved to: {output_csv}")
    except Exception as e:
        print(f"Error saving file {output_csv}: {str(e)}")


# Input and output file paths
acsf_file = "ACSF_results.txt"  # Replace with your actual file path
output_csv = "ACSF_results.csv"  # Replace with your desired output file path

# Call the function
acsf_to_csv(acsf_file, output_csv)
