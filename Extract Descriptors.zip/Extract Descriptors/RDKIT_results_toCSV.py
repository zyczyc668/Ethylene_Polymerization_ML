import pandas as pd
import os

def extract_rdkit_descriptors(input_file, output_csv):
    # Extract the folder name as the first column
    folder_name = os.path.basename(os.path.dirname(os.path.abspath(input_file)))

    # Initialize dictionary to store descriptors
    descriptors = {"Folder_Name": folder_name}

    # Read the input file
    with open(input_file, 'r') as file:
        lines = file.readlines()

    for line in lines:
        line = line.strip()
        if ": " in line:  # Check if the line contains a descriptor
            key, value = line.split(": ", 1)  # Split by ": "
            # Try converting value to float, otherwise keep as string
            try:
                value = float(value)
            except ValueError:
                pass  # Keep as string (e.g., for "nan")
            descriptors[key] = value

    # Create DataFrame from the dictionary
    df = pd.DataFrame([descriptors])

    # Save to CSV
    df.to_csv(output_csv, index=False)
    print(f"Descriptors saved to {output_csv}")


# Input and output file paths
input_file = "RDKIT_descriptors_results.txt"  # Replace with your actual file path
output_csv = "RDKIT_descriptors_results.csv"  # Replace with your desired output file path

# Run the function
extract_rdkit_descriptors(input_file, output_csv)
