# -*- coding: utf-8 -*-
import os
import sys
import pandas as pd
from rdkit import Chem
from rdkit.ML.Descriptors import MoleculeDescriptors
from rdkit.Chem import Descriptors

def RDKit_descriptors(smiles):
    """Calculate all descriptors for a given SMILES string."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, []  # Return None if SMILES is invalid
    mol = Chem.AddHs(mol)  # Add implicit hydrogens
    calc = MoleculeDescriptors.MolecularDescriptorCalculator(
        [x[0] for x in Descriptors._descList]
    )
    desc_names = calc.GetDescriptorNames()
    descriptors = calc.CalcDescriptors(mol)
    return descriptors, desc_names

def main():
    # Get CSV file path from command-line arguments
    if len(sys.argv) != 2:
        print("Usage: python 1.py <csv_file_path>")
        sys.exit(1)

    csv_file = sys.argv[1]

    # Check if the CSV file exists
    if not os.path.exists(csv_file):
        print(f"Error: File {csv_file} does not exist")
        sys.exit(1)

    # Read the CSV file
    df = pd.read_csv(csv_file)

    # Get the current folder name
    current_folder = os.path.basename(os.getcwd())

    # Find the row where 'molname' matches the current folder name
    matching_row = df[df["molname"] == current_folder]

    if matching_row.empty:
        print(f"Error: No matching 'molname' for the folder {current_folder} in {csv_file}")
        sys.exit(1)

    # Extract the 'Original SMILES' column
    smiles = matching_row["Original SMILES"].iloc[0]

    # Calculate descriptors
    descriptors, desc_names = RDKit_descriptors(smiles)
    if descriptors is None:
        print(f"Error: Invalid SMILES '{smiles}', descriptors cannot be calculated")
        sys.exit(1)

    # Write descriptors to a text file
    output_file = f"RDKIT_descriptors_results.txt"
    with open(output_file, "w") as f:
        f.write(f"SMILES: {smiles}\n")
        f.write("Descriptors:\n")
        for name, value in zip(desc_names, descriptors):
            f.write(f"{name}: {value}\n")

    print(f"Descriptors have been saved to {output_file}")

if __name__ == "__main__":
    main()
