# -*- coding: utf-8 -*-
import os
import math
import numpy as np
from numpy.linalg import norm
from numpy import dot, cross, arccos, degrees


def calculate_dihedral_angle(coord1, coord2, coord3, coord4):
    """
    Calculate the dihedral angle (in degrees) given the coordinates of four atoms.
    """
    x1, y1, z1 = coord1
    x2, y2, z2 = coord2
    x3, y3, z3 = coord3
    x4, y4, z4 = coord4

    # Vectors a, b, and c
    a = [x2 - x1, y2 - y1, z2 - z1]
    b = [x2 - x3, y2 - y3, z2 - z3]
    c = [x4 - x3, y4 - y3, z4 - z3]

    # Cross products to get normals to planes
    n1 = cross(a, b)
    n2 = cross(b, c)

    # Calculate dihedral angle
    z = dot(n1, n2) / (norm(n1) * norm(n2))
    z = np.clip(z, -1.0, 1.0)  # Handle numerical errors
    angle_rad = np.arccos(z)
    angle_deg = np.degrees(angle_rad)

    # Determine the sign of the angle
    m = cross(n1, n2)
    if dot(m, b) > 0:
        angle_deg = -angle_deg

    return angle_deg


def calculate_angle(coord1, coord2, coord3):
    """
    Calculate the angle (in degrees) between three atoms (coord1, coord2, coord3).
    """
    x1, y1, z1 = coord1
    x2, y2, z2 = coord2
    x3, y3, z3 = coord3

    # Vectors f and e
    f = (x2 - x1, y2 - y1, z2 - z1)  # Vector from coord1 to coord2
    e = (x3 - x1, y3 - y1, z3 - z1)  # Vector from coord1 to coord3

    # Calculate the angle between the vectors
    angle = arccos(dot(f, e) / (norm(f) * norm(e)))  # in radians
    angle_degrees = degrees(angle)  # Convert to degrees

    return angle_degrees


def calculate_distance(coord1, coord2):
    """
    Calculate the distance (in angstroms) between two atoms.
    """
    x1, y1, z1 = coord1
    x2, y2, z2 = coord2

    # Calculate the Euclidean distance
    distance = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2 + (z2 - z1) ** 2)
    
    return distance


def read_xyz_file(filename):
    """
    Read an XYZ file and return the atom coordinates as a list of tuples.
    """
    with open(filename, "r") as file:
        lines = file.readlines()

    # Extract atom coordinates starting from the 3rd line
    coordinates = []
    for line in lines[2:]:
        parts = line.split()
        x, y, z = map(float, parts[1:4])  # Extract x, y, z coordinates
        coordinates.append((x, y, z))

    return coordinates


def read_indices_from_file(file_path):
    indices = {}
    with open(file_path, 'r') as file:
        for line in file:
            if ":" in line:  # ȷ��ֻ��������ð�ŵ���
                key, value = line.split(":")
                indices[key.strip()] = int(value.strip())  # ��ȡkey������ֵ
    return indices


def find_indices_file():
    """
    Search for a file ending with 'bondAtom_index.txt' in the parent directory.
    """
    parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))
    for file in os.listdir(parent_dir):
        if file.endswith("bondAtom_index.txt"):
            return os.path.join(parent_dir, file)
    return None


def main():
    """
    Main function to calculate dihedral angles, angles, and distances from an XYZ file.
    """
    # Get the XYZ file name (same as the folder name)
    folder_name = os.path.basename(os.getcwd())
    xyz_file = f"{folder_name}.xyz"

    # Find the indices file in the parent directory
    indices_file = find_indices_file()
    if not indices_file:
        print("Error: No file ending with 'bondAtom_index.txt' found in the parent directory.")
        return

    print(f"Using indices file: {indices_file}")

    # Read R1-R5 indices from the TXT file
    try:
        indices = read_indices_from_file(indices_file)
        print(f"Successfully read indices: {indices}")
    except Exception as e:
        print(f"Error reading indices file: {e}")
        return

    # Check if the XYZ file exists
    if not os.path.exists(xyz_file):
        print(f"Error: XYZ file '{xyz_file}' not found.")
        return

    # Read the coordinates from the XYZ file
    coordinates = read_xyz_file(xyz_file)

    # Define the dihedral angles' atomic indices dynamically
    dihedrals = [
        [1, 6, 7, indices['R1_index']],
        [1, 5, 6, indices['R1_index']],
    ]

    # Define the angles' atomic indices dynamically
    angles = [
        [6, 1, 5],
        [6, 1, 7],
        [6, 1, 4],
        [7, 1, indices['R1_index']],
        [7, 6, indices['R1_index']],
        [6, 1, indices['R1_index']],
    ]

    # Define the distances' atomic indices dynamically
    distances = [
        [1, 6],
        [6, 7],
        [1, 4],
        [1, indices['R1_index']],
        [7, indices['R1_index']],
    ]

    # Open output file
    with open("Geometric_results.txt", "w") as output_file:

        # Calculate and print the dihedral angles
        for indices in dihedrals:
            if len(indices) != 4:
                print(f"Error: Invalid dihedral indices: {indices}")
                continue
            
            # Convert 1-based indices to 0-based
            i1, i2, i3, i4 = [index - 1 for index in indices]

            # Get the coordinates of the specified atoms
            coord1 = coordinates[i1]
            coord2 = coordinates[i2]
            coord3 = coordinates[i3]
            coord4 = coordinates[i4]

            # Calculate the dihedral angle
            angle = calculate_dihedral_angle(coord1, coord2, coord3, coord4)
            result = f"Dihedral angle for atoms {indices}: {angle:.2f} degrees"
            print(result)
            output_file.write(result + "\n")

        # Calculate and print the angles
        for indices in angles:
            if len(indices) != 3:
                print(f"Error: Invalid angle indices: {indices}")
                continue
            
            # Convert 1-based indices to 0-based
            i1, i2, i3 = [index - 1 for index in indices]

            # Get the coordinates of the specified atoms
            coord1 = coordinates[i1]
            coord2 = coordinates[i2]
            coord3 = coordinates[i3]

            # Calculate the angle
            angle = calculate_angle(coord1, coord2, coord3)
            result = f"Angle for atoms {indices}: {angle:.2f} degrees"
            print(result)
            output_file.write(result + "\n")

        # Calculate and print the distances
        for indices in distances:
            if len(indices) != 2:
                print(f"Error: Invalid distance indices: {indices}")
                continue
            
            # Convert 1-based indices to 0-based
            i1, i2 = [index - 1 for index in indices]

            # Get the coordinates of the specified atoms
            coord1 = coordinates[i1]
            coord2 = coordinates[i2]

            # Calculate the distance
            distance = calculate_distance(coord1, coord2)
            result = f"Distance between atoms {indices}: {distance:.3f} A"
            print(result)
            output_file.write(result + "\n")


if __name__ == "__main__":
    main()
