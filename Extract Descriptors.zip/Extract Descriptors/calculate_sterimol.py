import os
from morfeus import Sterimol, read_xyz

def calculate_sterimol_for_directory(directory, output_file="Sterimol_results.txt"):
    """
    Calculate Sterimol parameters for all .xyz files in the specified directory.

    Parameters:
    - directory: The directory containing .xyz files.
    - output_file: The name of the TXT file to save results.

    Outputs:
    - A TXT file with Sterimol results for each .xyz file.
    """
    # Prepare the output list
    results = []

    # Iterate through all files in the directory
    for filename in os.listdir(directory):
        if filename.endswith("_NoP_AND_Cr.xyz"):  # Process only files ending with '_NoP_AND_Cr.xyz'
            filepath = os.path.join(directory, filename)
            try:
                # Read the XYZ file
                elements, coordinates = read_xyz(filepath)

                # Assume the atoms for Sterimol calculation are 1 and 2 (adjust if needed)
                sterimol = Sterimol(elements, coordinates, 1, 2)

                # Extract Sterimol parameters
                l_value = sterimol.L_value
                b1_value = sterimol.B_1_value
                b5_value = sterimol.B_5_value

                # Print results to the console
                print(f"File: {filename}")
                print(f"L Value: {l_value:.2f}")
                print(f"B1 Value: {b1_value:.2f}")
                print(f"B5 Value: {b5_value:.2f}")

                # Save results to the list
                results.append({
                    "Filename": filename,
                    "L_value": round(l_value, 2),
                    "B_1_value": round(b1_value, 2),
                    "B_5_value": round(b5_value, 2)
                })

            except Exception as e:
                print(f"Error processing file {filename}: {e}")

    # Write results to the output TXT file
    with open(output_file, "w") as outfile:
        outfile.write("Sterimol Results\n")
        outfile.write("=" * 50 + "\n")
        for result in results:
            outfile.write(f"Filename: {result['Filename']}\n")
            outfile.write(f"L Value: {result['L_value']}\n")
            outfile.write(f"B1 Value: {result['B_1_value']}\n")
            outfile.write(f"B5 Value: {result['B_5_value']}\n")
            outfile.write("-" * 50 + "\n")

    print(f"Results saved to {output_file}")


if __name__ == "__main__":
    # Set the current directory as the working directory
    current_directory = os.getcwd()

    # Run the Sterimol calculation for all .xyz files in the directory
    calculate_sterimol_for_directory(current_directory)
