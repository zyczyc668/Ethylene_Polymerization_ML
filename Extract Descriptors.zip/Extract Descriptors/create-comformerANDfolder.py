import os

def extract_xyz_files_with_prefix_and_folders(input_file):
    """
    Extracts each xyz file from the input file, saves them with a prefix,
    creates a folder for each conformer, and moves the xyz file into its respective folder.
    
    Args:
        input_file (str): Input file containing all conformers.
    """
    try:
        # Get the current folder name as the prefix
        current_folder = os.path.basename(os.getcwd())
        prefix = current_folder + "_"

        with open(input_file, 'r') as file:
            lines = file.readlines()

        conformer_count = 0  # Counter for numbering conformer files
        conformer_lines = []  # Temporary storage for the current conformer data

        for line in lines:
            if line.strip().isdigit():  # Identify the start of a conformer by checking if the line is a number (atomic count)
                if conformer_lines:
                    # Save the previous conformer to a new file with the prefix
                    conformer_name = f"{prefix}conformer_{conformer_count + 1}"
                    output_filename = f"{conformer_name}.xyz"

                    # Write the conformer to its file
                    with open(output_filename, 'w') as output_file:
                        output_file.writelines(conformer_lines)
                    print(f"Conformer {conformer_count + 1} saved to {output_filename}")

                    # Create a folder for the conformer and move the xyz file into it
                    folder_name = conformer_name
                    os.makedirs(folder_name, exist_ok=True)  # Create the folder
                    os.rename(output_filename, os.path.join(folder_name, output_filename))  # Move the file into the folder
                    print(f"Folder {folder_name} created, and {output_filename} moved into it.")

                    conformer_count += 1
                    conformer_lines = []  # Clear temporary storage

            conformer_lines.append(line)

        # Save the last conformer
        if conformer_lines:
            conformer_name = f"{prefix}conformer_{conformer_count + 1}"
            output_filename = f"{conformer_name}.xyz"

            # Write the conformer to its file
            with open(output_filename, 'w') as output_file:
                output_file.writelines(conformer_lines)
            print(f"Conformer {conformer_count + 1} saved to {output_filename}")

            # Create a folder for the conformer and move the xyz file into it
            folder_name = conformer_name
            os.makedirs(folder_name, exist_ok=True)  # Create the folder
            os.rename(output_filename, os.path.join(folder_name, output_filename))  # Move the file into the folder
            print(f"Folder {folder_name} created, and {output_filename} moved into it.")

        print(f"\nTotal conformers extracted: {conformer_count + 1}")

    except FileNotFoundError:
        print(f"File {input_file} not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    # Replace with the name of your input file
    input_filename = "crest_conformers.xyz"
    extract_xyz_files_with_prefix_and_folders(input_filename)
