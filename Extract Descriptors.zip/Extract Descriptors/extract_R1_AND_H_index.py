from rdkit import Chem
import csv
import re
import os

def calculate_r1_indices(row, core_atom_count=4):
    """
    Calculate the atomic indices for the R1 group in a molecule.

    Parameters:
    - row: A dictionary representing a single row from the CSV file, with columns `molname`, `R1`, `R2`, and `R3`.
    - core_atom_count: Number of core atoms to exclude (default is 4).

    Returns:
    - A list of atomic indices corresponding to the R1 group.
    """
    atom_pattern = r'\[[^\]]+\]|[A-GI-Za-z]'

    r1 = row["R1"]
    r2 = row["R2"].strip() if "R4" in row else ""
    r3 = row["R3"].strip() if "R5" in row else ""

    r2_atoms = len(re.findall(atom_pattern, r2)) if r2 else 0
    r3_atoms = len(re.findall(atom_pattern, r3)) if r3 else 0
    r1_atoms = len(re.findall(atom_pattern, r1))

    r1_start = core_atom_count + r2_atoms + r3_atoms + 1
    r1_end = r1_start + r1_atoms - 1

    return list(range(r1_start, r1_end + 1))


def extract_hydrogens_for_atom(mol_file, atom_index):
    """
    Extract all hydrogens bonded to the specified atom in the molecule.

    Parameters:
    - mol_file: Path to the MOL file (or SDF file) to analyze.
    - atom_index: Index of the target atom (1-based index as in the MOL file).

    Returns:
    - A list of hydrogen atom indices (1-based indices as in the MOL file).
    """
    mol = Chem.MolFromMolFile(mol_file, removeHs=False)
    if mol is None:
        raise ValueError(f"Failed to load molecule from file: {mol_file}")
    
    # Convert to 0-based index for RDKit
    rdkit_idx = atom_index - 1
    target_atom = mol.GetAtomWithIdx(rdkit_idx)
    
    # Get neighbors and find hydrogens
    bonded_hydrogens = []
    for neighbor in target_atom.GetNeighbors():
        if neighbor.GetSymbol() == "H":
            bonded_hydrogens.append(neighbor.GetIdx() + 1)  # Convert back to 1-based index
    
    return bonded_hydrogens


def process_molecule(row, mol_file):
    """
    Process a single molecule row and mol file to extract R1 and N3 hydrogen indices.
    """
    r1_indices = calculate_r1_indices(row)
    bonded_hydrogens_r1 = {}
    bonded_hydrogens_n3 = []

    # Find hydrogens for each R1 index
    for atom_index in r1_indices:
        h_indices = extract_hydrogens_for_atom(mol_file, atom_index)
        bonded_hydrogens_r1[atom_index] = h_indices

    # Find hydrogens for the 3rd nitrogen atom (N3)
    bonded_hydrogens_n3 = extract_hydrogens_for_atom(mol_file, 3)

    return r1_indices, bonded_hydrogens_r1, bonded_hydrogens_n3


def save_results(molname, r1_indices, bonded_hydrogens_r1, bonded_hydrogens_n3):
    """
    Save the results for a molecule to a TXT file.

    Parameters:
    - molname: Name of the molecule (used in filename).
    - r1_indices: List of R1 indices.
    - bonded_hydrogens_r1: Dict of R1 atom indices to hydrogen indices.
    - bonded_hydrogens_n3: List of hydrogen indices bonded to N3.
    """
    filename = f"{molname}_R1_AND_H_index.txt"
    with open(filename, "w") as file:
        file.write(f"R1_Indices: {r1_indices}\n")
        file.write(f"Bonded H (R1): {bonded_hydrogens_r1}\n")
        file.write(f"Bonded H (N3): {bonded_hydrogens_n3}\n")
    print(f"Results saved to {filename}")


def main(input_file):
    """
    Main function to process the input CSV file and find hydrogens for R1 indices and N(3).
    """
    current_folder = os.path.basename(os.getcwd())  # Get the current folder name
    try:
        with open(input_file, mode="r", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            print(f"Detected columns: {reader.fieldnames}")

            if "molname" not in reader.fieldnames or "R1" not in reader.fieldnames or "R4" not in reader.fieldnames or "R5" not in reader.fieldnames:
                raise ValueError("Required columns (molname, R1, R4, R5) not found in the CSV file.")

            for row in reader:
                molname = row["molname"]
                # Only process the molecule if its name matches the current directory
                if molname == current_folder:
                    mol_file = f"{molname}.mol"  # Assume .mol files are named after molname
                    if os.path.exists(mol_file):
                        try:
                            # Process the molecule
                            r1_indices, bonded_hydrogens_r1, bonded_hydrogens_n3 = process_molecule(row, mol_file)

                            # Save the results
                            save_results(molname, r1_indices, bonded_hydrogens_r1, bonded_hydrogens_n3)
                        except Exception as e:
                            print(f"{molname}: Error processing molecule - {e}")
                    else:
                        print(f"{molname}: No corresponding .mol file found. Skipping.")
    except FileNotFoundError:
        print(f"Error: File {input_file} not found.")
    except Exception as e:
        print(f"Error processing file: {e}")


if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python extract_R1_indices_with_hydrogens.py <input_csv_file>")
    else:
        main(sys.argv[1])
