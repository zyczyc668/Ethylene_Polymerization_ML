import csv
import re
import os

def calculate_binding_indices(row, core_atom_count=7):
    """
    Calculate the atomic indices for R2, R3 groups connected to core atoms (Cr, P1, N, P2).
    """
    atom_pattern = r'(Cl|Br|Si|[A-GI-Za-z])'
    r1 = row.get("R1", "").strip()
    r2 = row.get("R2", "").strip()
    r3 = row.get("R3", "").strip()
    r1_atoms = len(re.findall(atom_pattern, r1))
    r2_atoms = len(re.findall(atom_pattern, r2))
    r3_atoms = len(re.findall(atom_pattern, r3))
    if r1 == "H" and r2 != "H" and r3 != "H":
        r1_index = r2_atoms*2 + r3_atoms + 18
        r2_index = 9
        return r1_index, r2_index
        
    if r1 == "H" and r2 == "H" and r3 != "H":
        r1_index = r3_atoms + 18
        r2_index = 9
        return r1_index, r2_index       

    if r1 == "H" and r2 == "H" and r3 == "H":
        r1_index = 19
        r2_index = 9
        return r1_index, r2_index     

    if r1 == "H" and r2 != "H" and r3 == "H":
        r1_index = r2_atoms*2 + 19
        r2_index = 9
        return r1_index, r2_index          
        
    else:
        r1_index = 8
        r2_index = r1_atoms + 9
        return r1_index, r2_index

def save_to_txt(molname, indices):
    """
    Save the indices for a molecule to a TXT file.
    """
    filename = f"{molname}_bondAtom_index.txt"
    with open(filename, "w") as file:
        file.write(f"R1_index: {indices[0]}\n")
        file.write(f"R2_index: {indices[1]}\n")
    return filename

def main(input_file):
    """
    Read the input CSV file and calculate binding atom indices for each molecule, only for the current directory's folder.
    """
    current_folder = os.path.basename(os.getcwd())  # Get the current folder name
    try:
        # Read the CSV file
        with open(input_file, mode="r", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            for row in reader:
                molname = row.get("molname", "Unknown")
                # Only generate the index file if the molecule's name matches the current folder name
                if molname == current_folder:
                    try:
                        # Calculate the binding atom indices
                        r1_index, r2_index = calculate_binding_indices(row)
                        filename = save_to_txt(molname, (r1_index, r2_index))
                        print(f"Saved {filename}")
                    except Exception as e:
                        print(f"{molname:<10} Error: {e}")
    except FileNotFoundError:
        print(f"Error: File {input_file} not found.")
    except Exception as e:
        print(f"Error processing file: {e}")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python extract_binding_indices.py <input_csv_file>")
    else:
        input_file = sys.argv[1]
        main(input_file)
