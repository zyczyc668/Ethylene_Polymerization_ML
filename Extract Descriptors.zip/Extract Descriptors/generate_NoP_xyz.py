import os
import re


def parse_txt_file(txt_file):
    """
    Parse the input TXT file to extract R1 indices, bonded H indices for R1, and bonded H for N3.
    """
    with open(txt_file, "r") as file:
        lines = file.readlines()

    # Parse R1 indices from the first line
    r1_indices_line = lines[0].strip()
    r1_indices_match = re.search(r"\[([^\]]+)\]", r1_indices_line)
    if not r1_indices_match:
        raise ValueError("Failed to parse R1 indices from the first line")
    r1_indices = list(map(int, r1_indices_match.group(1).split(",")))

    # Parse bonded H (R1) from the second line
    bonded_h_r1_line = lines[1].strip()
    bonded_h_r1 = {}
    bonded_h_r1_matches = re.findall(r"(\d+): \[([^\]]+)\]", bonded_h_r1_line)
    for match in bonded_h_r1_matches:
        atom_index = int(match[0])
        h_indices = list(map(int, match[1].split(",")))
        bonded_h_r1[atom_index] = h_indices

    # Parse bonded H (N3) from the third line, handle empty case
    bonded_h_n3_line = lines[2].strip()
    bonded_h_n3 = []
    bonded_h_n3_match = re.search(r"\[([^\]]+)\]", bonded_h_n3_line)
    if bonded_h_n3_match:
        bonded_h_n3 = list(map(int, bonded_h_n3_match.group(1).split(",")))

    return r1_indices, bonded_h_r1, bonded_h_n3


def filter_xyz_file(molname, cr_index, n_index, r1_indices, h_indices):
    """
    Filter and reorder an XYZ file to keep only the specified atoms, in the desired order.
    """
    input_file = f"{molname}.xyz"
    output_file = f"{molname}_NoP.xyz"

    # Read the original XYZ file
    with open(input_file, "r") as infile:
        lines = infile.readlines()

    # First two lines are the atom count and a comment
    original_atom_count = int(lines[0].strip())
    comment_line = lines[1].strip()

    # The remaining lines contain the atom data
    atom_lines = lines[2:]

    # Create a new order: Cr -> N3 -> R1 -> H
    ordered_indices = [cr_index - 1, n_index - 1] + [i - 1 for i in r1_indices] + [i - 1 for i in h_indices]

    # Filter and reorder the atoms
    filtered_atoms = [atom_lines[i] for i in ordered_indices]

    # Update the atom count
    filtered_atom_count = len(filtered_atoms)

    # Write the new XYZ file
    with open(output_file, "w") as outfile:
        outfile.write(f"{filtered_atom_count}\n")
        outfile.write(f"{comment_line}\n")
        outfile.writelines(filtered_atoms)

    print(f"Filtered and reordered XYZ file saved to: {output_file}")


def main():
    """
    Main function to parse the TXT file and process the corresponding XYZ file.
    """
    try:
        # Automatically get the basename of the current folder as molname
        molname = os.path.basename(os.getcwd())

        # Find the TXT file in the parent directory ending with "_R1_AND_H_index.txt"
        parent_dir = os.path.dirname(os.getcwd())
        txt_file = None
        for file in os.listdir(parent_dir):
            if file.endswith("_R1_AND_H_index.txt"):
                txt_file = os.path.join(parent_dir, file)
                break

        if not txt_file:
            raise FileNotFoundError("No TXT file ending with '_R1_AND_H_index.txt' found in the parent directory.")

        # Parse the TXT file
        r1_indices, bonded_h_r1, bonded_h_n3 = parse_txt_file(txt_file)

        # Collect all H indices (R1 + N3, if present)
        r1_h_indices = [h for hlist in bonded_h_r1.values() for h in hlist]
        all_h_indices = r1_h_indices + bonded_h_n3

        # Filter and reorder the XYZ file
        filter_xyz_file(
            molname,
            cr_index=1,  # Assuming Cr is always the first atom
            n_index=3,   # Assuming N3 is the third atom
            r1_indices=r1_indices,
            h_indices=all_h_indices,
        )

    except Exception as e:
        print(f"Error processing file: {e}")


if __name__ == "__main__":
    main()
