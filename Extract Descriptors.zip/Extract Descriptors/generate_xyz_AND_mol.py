import csv
import sys
import pandas as pd
import os
from rdkit import Chem
from rdkit.Chem import AllChem
import re  # Import regular expressions module for replacing special characters
from rdkit import RDLogger
import math

# Disable all RDKit warnings and error messages
RDLogger.DisableLog('rdApp.*')

# Function to generate a valid filename from the molecule name
def sanitize_filename(molname):
    """
    Replace any special characters (like parentheses, slashes, etc.) with underscores.
    Only allow alphanumeric characters, underscores, hyphens, and periods.
    """
    return re.sub(r'[^\w\-\.]', '_', molname)

def smiles_to_xyz(smiles, molname, max_attempts=100):
    """
    Convert a SMILES string to XYZ and MOL files.
    If embedding fails, it retries up to `max_attempts` times.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        print(f"Failed to parse SMILES: {smiles}")
        return None

    # Add hydrogens and prepare molecule for 3D embedding
    mol = Chem.AddHs(mol)  # Add hydrogen atoms
    
    success = False
    for attempt in range(max_attempts):
        try:
            # Try to embed the molecule with 3D coordinates
            if AllChem.EmbedMolecule(mol, maxAttempts=20) == 0:
                success = True
                break
        except Exception as e:
            print(f"Error embedding molecule {molname} on attempt {attempt + 1}: {e}")
    
    if not success:
        print(f"Failed to embed molecule after {max_attempts} attempts: {molname}")
        with open("embedding_errors.log", "a") as log_file:
            log_file.write(f"Failed to embed {molname}: {smiles}\n")
        return None

    # Get the atom coordinates from the optimized molecule
    conf = mol.GetConformer()

    # Sanitize molecule name to create a valid filename
    sanitized_name = sanitize_filename(molname)

    # Generate MOL file
    mol_filename = f"{sanitized_name}.mol"
    try:
        with open(mol_filename, "w") as mol_file:
            mol_file.write(Chem.MolToMolBlock(mol))
        print(f"Generated: {mol_filename}")
    except Exception as e:
        print(f"Error writing MOL file for {molname}: {e}")
        return None

    # Generate XYZ file
    xyz_filename = f"{sanitized_name}.xyz"
    try:
        with open(xyz_filename, "w") as xyz_file:
            xyz_file.write(f"{mol.GetNumAtoms()}\n")  # Write the number of atoms
            xyz_file.write(f"{molname}\n")  # Write the molecule name as the second line
            for atom in mol.GetAtoms():
                pos = conf.GetAtomPosition(atom.GetIdx())  # Get the position of each atom
                xyz_file.write(f"{atom.GetSymbol()} {pos.x:.4f} {pos.y:.4f} {pos.z:.4f}\n")
        print(f"Generated: {xyz_filename}")
    except Exception as e:
        print(f"Error writing XYZ file for {molname}: {e}")
        return None

def process_csv(input_csv_path):
    """
    Process a CSV file containing SMILES strings and molecule names.
    Generates XYZ and MOL files for each molecule.
    """
    # Read the CSV file
    df = pd.read_csv(input_csv_path)

    # Log file for errors
    with open("embedding_errors.log", "w") as log_file:
        log_file.write("Embedding Errors:\n")

    # Loop through each row in the CSV file
    for index, row in df.iterrows():
        try:
            smiles = row[4]  # SMILES string is assumed to be in the 7th column (index 6)
            molname = row[0]  # Molecule name is in the first column
            smiles_to_xyz(smiles, molname)
        except Exception as e:
            print(f"Error processing row {index} ({row[0]}): {e}")
            with open("embedding_errors.log", "a") as log_file:
                log_file.write(f"Error processing {row[0]}: {e}\n")

if __name__ == "__main__":
    # Check if the input file path is provided as a command line argument
    if len(sys.argv) != 2:
        print("Usage: python csv_to_xyz.py <input CSV file>")
        sys.exit(1)

    input_csv_path = sys.argv[1]  # Get the input CSV file path

    # Check if the provided CSV file exists
    if not os.path.exists(input_csv_path):
        print(f"File not found: {input_csv_path}")
        sys.exit(1)

    # Process the CSV file to generate XYZ and MOL files
    process_csv(input_csv_path)
