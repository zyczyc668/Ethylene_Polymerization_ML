import os
import pandas as pd

def extract_data_with_titles(geometry_file, output_csv):
    # Define the row titles
    dihedral_titles = ["Dihedral_" + "_".join(map(str, dihedral)) for dihedral in [
        [1, 6, 7, "R1"], [1, 5, 6, "R1"]
    ]]

    angle_titles = ["Angle_" + "_".join(map(str, angle)) for angle in [
        [6, 1, 5], [6, 1, 7], [6, 1, 4], [7, 1, "R1"], [7, 6, "R1"], [6, 1, "R1"]
    ]]

    distance_titles = ["Distance_" + "_".join(map(str, distance)) for distance in [
        [1, 6], [6, 7], [1, 4], [1, "R1"], [7, "R1"]
    ]]

    all_titles = ["Folder_Name"] + dihedral_titles + angle_titles + distance_titles

    # Extract folder name from file path
    folder_name = os.path.basename(os.path.dirname(os.path.abspath(geometry_file)))

    # Initialize the result with folder name
    results = [folder_name]

    # Read the geometric results file
    with open(geometry_file, 'r') as file:
        lines = file.readlines()

    for line in lines:
        line = line.strip()
        if line.startswith("Dihedral angle for atoms") or line.startswith("Angle for atoms") or line.startswith("Distance between atoms"):
            # Extract the second-to-last value
            parts = line.split()
            value = float(parts[-2])  # Second-to-last value is the numeric data
            results.append(value)

    # Check if results match the number of titles (excluding folder name)
    if len(results) != len(all_titles):
        raise ValueError("Number of extracted values does not match the number of titles. Check the input file structure.")

    # Create a DataFrame
    df = pd.DataFrame([results], columns=all_titles)

    # Save to CSV
    df.to_csv(output_csv, index=False)
    print(f"Converted file saved to: {output_csv}")


# File paths
geometry_file = "Geometric_results.txt"  # Replace with your actual file path
output_csv = "Geometric_results.csv"  # Replace with your desired output file path

# Run the function
extract_data_with_titles(geometry_file, output_csv)
