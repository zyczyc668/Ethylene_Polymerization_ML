# -*- coding: utf-8 -*-

import re

def read_xtb_log():
    # Initialize flags and data containers
    read_mul = False
    read_wil = False
    read_dip = False
    read_fukui = False
    read_orbital_energies = False

    muls = []
    alphas = []
    wils = []
    dip = [0.0, 0.0, 0.0]
    alpha = None
    fukui = []
    HOMO_LUMO_gap = None

    # Initialize variables for HOMO and LUMO energies
    homo_energy = None
    lumo_energy = None

    # Variables for "xtb_ipea.log"
    global_electrophilicity_index = None
    EA_delta_SCC = None
    IP_delta_SCC = None
    empirical_EA_shift = None
    empirical_IP_shift = None

    # Compile regex patterns for HOMO, LUMO, and HL-Gap
    homo_pattern = re.compile(r'(-?\d+\.\d+)\s*\(HOMO\)')
    lumo_pattern = re.compile(r'(-?\d+\.\d+)\s*\(LUMO\)')
    hl_gap_pattern = re.compile(r'HL-Gap\s+[-\d.]+\s+Eh\s+([-]?\d+\.\d+)\s+eV')
    fukui_header_pattern = re.compile(r'#\s*f\(\+\)\s*f\(-\)\s*f\(0\)', re.IGNORECASE)

    # Read and parse "xtb.log"
    with open("xtb.log", "r", encoding="utf-8") as file:
        for line in file:
            if "convergence criteria cannot be satisfied within" in line:
                break

            parts = line.strip().split()

            # Reset flags if an empty line is encountered
            if read_mul and not parts:
                read_mul = False
            if read_fukui and not parts:
                read_fukui = False
            if read_wil and not parts:
                read_wil = False
            if read_orbital_energies and not parts:
                read_orbital_energies = False
            if read_dip and "molecular quadrupole" in line:
                read_dip = False

            # Extract Fukui indices
            if read_fukui:
                if len(parts) >= 4:
                    try:
                        fukui.append([
                            float(parts[1]),
                            float(parts[2]),
                            float(parts[3])
                        ])
                    except ValueError:
                        pass  # Handle lines that do not contain valid floats

            # Extract Mulliken charges and polarizability
            if read_mul:
                if len(parts) >= 7:
                    try:
                        muls.append(float(parts[4]))
                        alphas.append(float(parts[6]))
                    except ValueError:
                        pass  # Handle lines that do not contain valid floats

            # Extract Wiberg bond orders
            if read_wil:
                if len(parts) >= 4:
                    try:
                        wbo_value = float(parts[3])
                        wils.append(wbo_value)
                    except ValueError:
                        pass  # Skip lines that do not contain valid floats

            # Extract dipole moment
            if read_dip and "full:" in line and len(parts) > 4:
                try:
                    dip = [
                        float(parts[1]),
                        float(parts[2]),
                        float(parts[3])
                    ]
                except ValueError:
                    pass  # Handle lines that do not contain valid floats

            # Extract occupied orbital information
            if read_orbital_energies and "occ." in line.lower():
                occ = []
                for x in parts[1:]:
                    try:
                        occ.append(int(round(float(x))))
                    except ValueError:
                        occ.append(0)  # Default to 0 if conversion fails

            # Extract orbital energies
            if read_orbital_energies and "eps" in line.lower():
                es = []
                for x in parts[1:]:
                    try:
                        es.append(float(x))
                    except ValueError:
                        es.append(0.0)  # Default to 0.0 if conversion fails

                if len(es) == len(occ):
                    for idx in range(len(es)):
                        if occ[idx] > 0:
                            # Append to occupied energies if occupation > 0
                            # Not used in final output but kept for completeness
                            pass
                        else:
                            # Append to virtual energies if occupation == 0
                            # Not used in final output but kept for completeness
                            pass

            # Extract alpha polarizability
            if "Mol. \u03B1(0) /au        :" in line:
                try:
                    alpha = float(parts[4])
                except ValueError:
                    alpha = None  # Assign None if conversion fails

            # Extract HOMO and LUMO energies using regex
            homo_match = homo_pattern.search(line)
            if homo_match:
                try:
                    homo_energy = float(homo_match.group(1))
                except ValueError:
                    homo_energy = None

            lumo_match = lumo_pattern.search(line)
            if lumo_match:
                try:
                    lumo_energy = float(lumo_match.group(1))
                except ValueError:
                    lumo_energy = None

            # Extract HOMO-LUMO gap using regex
            hl_gap_match = hl_gap_pattern.search(line)
            if hl_gap_match:
                try:
                    HOMO_LUMO_gap = float(hl_gap_match.group(1))
                except ValueError:
                    HOMO_LUMO_gap = None

            # Set flags based on header lines
            if "#   Z          covCN         q      C6AA" in line:
                read_mul = True
            if "#   Z sym  total        # sym  WBO       # sym  WBO       # sym  WBO" in line:
                read_wil = True
            if "molecular dipole:" in line:
                read_dip = True
            if "#        f(+)     f(-)     f(0)" in line:
                read_fukui = True
            if "eigenvalues" in line.lower():
                read_orbital_energies = True

    # Read and parse "xtb_ipea/xtb_ipea.log"
    with open("xtb_ipea.log", "r", encoding="utf-8") as file:
        for line in file:
            if "convergence criteria cannot be satisfied within" in line:
                break

            parts = line.split()

            if "Global electrophilicity index (eV):" in line:
                try:
                    global_electrophilicity_index = float(parts[4])
                except ValueError:
                    global_electrophilicity_index = None

            if "empirical EA shift (eV):" in line:
                try:
                    empirical_EA_shift = float(parts[4])
                except ValueError:
                    empirical_EA_shift = None

            if "delta SCC EA (eV):" in line:
                try:
                    EA_delta_SCC = float(parts[4])
                except ValueError:
                    EA_delta_SCC = None

            if "empirical IP shift (eV):" in line:
                try:
                    empirical_IP_shift = float(parts[4])
                except ValueError:
                    empirical_IP_shift = None

            if "delta SCC IP (eV):" in line:
                try:
                    IP_delta_SCC = float(parts[4])
                except ValueError:
                    IP_delta_SCC = None

    # Read and parse "xtb_esp_profile.dat"
    esp_profile = []
    with open("xtb_esp_profile.dat", "r", encoding="utf-8") as file:
        for line in file:
            parts = line.split()
            if len(parts) == 2:
                try:
                    esp_profile.append([float(parts[0]), float(parts[1])])
                except ValueError:
                    pass  # Handle lines that do not contain valid floats

    # Read and parse "xtb_esp.dat"
    esp_points = []
    with open("xtb_esp.dat", "r", encoding="utf-8") as file:
        for line in file:
            parts = line.split()
            if len(parts) == 4:
                try:
                    esp_points.append([
                        float(parts[0]),
                        float(parts[1]),
                        float(parts[2]),
                        float(parts[3])
                    ])
                except ValueError:
                    pass  # Handle lines that do not contain valid floats

    # Calculate nucleophilicity
    nucleophilicity = -IP_delta_SCC if IP_delta_SCC is not None else None

    # Write extracted data to "results.txt"
    with open("Electronic-results.txt", "w", encoding="utf-8") as output_file:
        # Mulliken charges
        output_file.write("Mulliken charges:\n")
        for mul, alpha_val in zip(muls, alphas):
            output_file.write(f"{mul} {alpha_val}\n")
        output_file.write("\n")

        # Wiberg bond orders
        output_file.write("Wiberg bond orders:\n")
        for wbo in wils:
            output_file.write(f"{wbo}\n")
        output_file.write("\n")

        # HOMO and LUMO energies
        output_file.write("HOMO energy:\n")
        if homo_energy is not None:
            output_file.write(f"{homo_energy}\n")
        else:
            output_file.write("N/A\n")
        output_file.write("\n")

        output_file.write("LUMO energy:\n")
        if lumo_energy is not None:
            output_file.write(f"{lumo_energy}\n")
        else:
            output_file.write("N/A\n")
        output_file.write("\n")

        # HOMO-LUMO gap
        output_file.write("HOMO-LUMO gap:\n")
        if HOMO_LUMO_gap is not None:
            output_file.write(f"{HOMO_LUMO_gap}\n")
        else:
            output_file.write("N/A\n")
        output_file.write("\n")

        # Fukui indices
        output_file.write("Fukui indices:\n")
        for f in fukui:
            output_file.write(f"{f[0]} {f[1]} {f[2]}\n")
        output_file.write("\n")

        # Dipole moment
        output_file.write("Dipole moment:\n")
        output_file.write(f"{dip[0]} {dip[1]} {dip[2]}\n")
        output_file.write("\n")

        # Alpha polarizability
        output_file.write("Alpha polarizability:\n")
        output_file.write(f"{alpha}\n")
        output_file.write("\n")

        # Global electrophilicity index
        output_file.write("Global electrophilicity index:\n")
        if global_electrophilicity_index is not None:
            output_file.write(f"{global_electrophilicity_index}\n")
        else:
            output_file.write("N/A\n")
        output_file.write("\n")

        # Nucleophilicity
        output_file.write("Nucleophilicity:\n")
        if nucleophilicity is not None:
            output_file.write(f"{nucleophilicity}\n")
        else:
            output_file.write("N/A\n")
        output_file.write("\n")
        
        # Electrostatic potential profile
        output_file.write("Electrostatic potential profile:\n")
        for point in esp_profile:
            output_file.write(f"{point[0]} {point[1]}\n")
        output_file.write("\n")

        # Electrostatic potential points
        output_file.write("Electrostatic potential points:\n")
        for point in esp_points:
            output_file.write(f"{point[0]} {point[1]} {point[2]} {point[3]}\n")
        output_file.write("\n")

    return (
        muls, alphas, wils, dip, alpha, fukui, HOMO_LUMO_gap,
        IP_delta_SCC, EA_delta_SCC, global_electrophilicity_index,
        esp_profile, esp_points, nucleophilicity,
        homo_energy, lumo_energy
    )

# Run the script
if __name__ == "__main__":
    read_xtb_log()
    print("Results have been written to results.txt.")
