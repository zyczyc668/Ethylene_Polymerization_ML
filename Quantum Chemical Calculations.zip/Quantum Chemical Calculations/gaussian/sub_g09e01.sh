rm "\*\.gjf" >/dev/null 2>&1

if [ "$( ls | grep '\.gjf' 2> /dev/null )" ]; then
FN=$(ls -v *.gjf )
for i in ${FN}; do
        i=${i%.gjf}
        rm -r ${i} 2> /dev/null
        mkdir ${i}
        mv ${i}.gjf ${i}.chk ./${i} 2> /dev/null
        cp run_g09e01.sh ./${i}/gau_${i}
        cd ${i}

 sed -i "/^%[cC][hH][kK]/ c\%chk=${i}.chk" ${i}.gjf
 sed -i "s/JOB_NAME/$i/g" gau_${i}
        sbatch gau_${i}
        touch $(squeue --format="%.18i%.20u" | grep "${USER}" | sort -k 1  | awk '{print $1}' | tail -n1)
        cd ..
   done
else
   echo "No gaussian input file (.gjf) found! Please check!)"
fi
