#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=40
#SBATCH -o runlog
#SBATCH --time=48:00:00
#SBATCH -p q1

ulimit -s unlimited
ulimit -l unlimited

input=FILENAME
Indir=INDIR
CHARGE=0
UNPAIRED=3
SOLVENT=toluene

WORKDIR=${SLURM_SUBMIT_DIR}
HN=$(echo ${SLURMD_NODENAME})
mkdir -p /state/partition1/tmp/${USER}/${SLURM_JOB_ID}
tdir=/state/partition1/tmp/${USER}/${SLURM_JOB_ID}

touch "$Indir/running_by_${HN}"
touch "$Indir/${SLURM_JOB_ID}"

# Copy the input directory to temporary directory
cp -r $Indir $tdir
cd $tdir/$input

# Clean up old xtb files
rm -rf xtbopt.xyz charges wbo xtbrestart xtbtopo.mol 2> /dev/null

# Run xtb optimization
/home/${USER}//bin/xtb-dist/bin/xtb ${input}.xyz --opt --gbsa ${SOLVENT} --chrg ${CHARGE} --uhf ${UNPAIRED} --gfnff -T 24 > $Indir/${input}.log 2>&1

# Rename files if optimization is successful
if [[ -f "xtbopt.xyz" ]]; then
    mv "${input}.xyz" "${input}-initial.xyz"  # Rename original input file
    mv "xtbopt.xyz" "${input}.xyz"           # Rename optimized file to original name
fi

# Copy the results back to the original directory
cp $tdir/$input/* $Indir

# Clean up the temporary directory
rm -rf /state/partition1/tmp/${USER}/${SLURM_JOB_ID} "$Indir/running_by_${HN}"

# ---END of the Script---
