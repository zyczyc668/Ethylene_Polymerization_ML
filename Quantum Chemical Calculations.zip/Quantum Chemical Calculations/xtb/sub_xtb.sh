#!/bin/bash

FN=$1

FN=$(echo $FN | sed "s/.xyz//g")

if [ "$(ls | grep '.xyz' 2> /dev/null)" ]; then
    for i in ${FN}; do
        # Create a folder for each input file
        rm -r ${i} 2> /dev/null
        mkdir ${i}
        mv ${i}.* ./${i} 2> /dev/null
        cp run_xtb.sh ./${i}/xtb_${i}
        cd ${i}
        
        # Update the placeholders in the run_xtb.sh script
        sed -i "s/FILENAME/${i}/g" xtb_${i}
        sed -i s,INDIR,`pwd`,g xtb_${i}
        
        # Submit the job using SLURM
        sbatch xtb_${i}
        cd ..
    done
else
    echo "No xtb input file (.xyz) found! Please check!"
fi
